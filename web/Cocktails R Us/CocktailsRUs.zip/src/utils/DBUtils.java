package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Category;
import beans.Customer;
import beans.Product;

public class DBUtils {
    
    public static Customer findUser(Connection conn,
            String userName) throws SQLException {
        
        String sql = "Select c.name, c.email, c.phone,c.address, c.city_region,c.cc_number from Customer c " //
                + " where c.name = ? ";
        
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, userName);
        
        ResultSet rs = pstm.executeQuery();
        
        if (rs.next()) {
            Customer user = new Customer();
            user.setName(rs.getString("name"));
            user.setEmail(rs.getString("email"));
            user.setPhone(rs.getString("phone"));
            user.setAddress(rs.getString("address"));
            user.setCityRegion(rs.getString("city_region"));
            user.setCcNumber(rs.getString("cc_number"));
            return user;
        }
        return null;
    }
    
    public static List<Product> queryProduct(Connection conn) throws SQLException {
//        String sql = "Select p.name,p.price,p.description,c.name,c.id from Product p inner join Category c on c.id=p.category_id";
        String sql = "select * from Product p, Category c";
        PreparedStatement pstm = conn.prepareStatement(sql);
        
        ResultSet rs = pstm.executeQuery();
        List<Product> list = new ArrayList<Product>();
        while (rs.next()) {
            
            Product product = new Product();
            product.setName(rs.getString("p.name"));
            product.setPrice(rs.getBigDecimal("p.price"));
            product.setDescription(rs.getString("p.description"));
            product.setCategory(new Category(rs.getShort("c.id"), rs.getString("c.name")));
            
            list.add(product);
        }
        return list;
    }
    
    public static void insertProduct(Connection conn, Product prod) throws SQLException {
        //String sql = "Select p.name,p.price,p.description,c.name,c.id from Product p inner join Category c on c.id=p.category_id";
        String sql = "insert into Product(name,category_id,price) values(?,?,?)";
        PreparedStatement pstm = conn.prepareStatement(sql);
        
        pstm.setString(1, prod.getName());
        pstm.setInt(2, prod.getCategory().getId());
        pstm.setBigDecimal(3, prod.getPrice());
        pstm.execute();
        
    }
    
    public static Product findProduct(Connection conn, String code) throws SQLException {
        Product prod = new Product();
        String sql = "select * from Product p, Category c where p.name = ?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, code);        
        ResultSet rs = pstm.executeQuery();
        while (rs.next()) {
            
            prod.setName(rs.getString("p.name"));
            prod.setPrice(rs.getBigDecimal("p.price"));
            prod.setDescription(rs.getString("p.description"));
            prod.setCategory(new Category(rs.getShort("c.id")));
            
        }
        return prod;
    }
    
}
